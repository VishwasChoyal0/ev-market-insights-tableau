from pathlib import Path
import pandas as pd
import json, time, hashlib

base=Path(__file__).resolve().parent
out=base.parent/'outputs'/'EV Market Insights'
(out/'data').mkdir(parents=True,exist_ok=True)
start=time.perf_counter()
parts=[]
for split in ('train','test'):
    d=pd.read_csv(base/'dataset'/f'ev_market_{split}.csv')
    d['source_split']=split
    parts.append(d)
d=pd.concat(parts,ignore_index=True)
raw_count=len(d)
exact=int(d.drop(columns='source_split').duplicated().sum())
missing={k:int(v) for k,v in d.isna().sum().items() if v}
duplicate_ids=d[d.vehicle_id.duplicated(keep=False)].sort_values('vehicle_id')
duplicate_ids.to_csv(base/'vehicle_id_duplicates.csv',index=False)
# Repeated identifiers alone do not prove record duplication; remove only exact rows.
for c in d.select_dtypes(include='object'):
    d[c]=d[c].str.strip()
d=d.drop_duplicates(subset=[c for c in d.columns if c!='source_split'])
d['record_key']=d['source_split']+'-'+(d.groupby('source_split').cumcount()+1).astype(str)
invalid={}
for c,lo,hi in [('annual_sales_units',0,None),('customer_rating',0,5),('range_km',0,None),('battery_capacity_kwh',0,None),('price_usd',0,None)]:
    mask=d[c].notna() & (d[c].lt(lo) | (d[c].gt(hi) if hi is not None else False))
    invalid[c]=int(mask.sum())
    d.loc[mask,c]=float('nan')
d.to_csv(out/'data'/'ev_market_clean.csv',index=False)
metrics={'raw_rows':raw_count,'clean_rows':len(d),'columns':len(d.columns),'exact_duplicates_removed':exact,'raw_duplicate_id_rows':len(duplicate_ids),'missing_values':missing,'invalid_values':invalid,'year_min':int(d.model_year.min()),'year_max':int(d.model_year.max()),'total_sales':float(d.annual_sales_units.sum()),'sales_records':int(d.annual_sales_units.count()),'mean_rating':float(d.customer_rating.mean()),'mean_range':float(d.range_km.mean()),'manufacturers':int(d.manufacturer.nunique()),'countries':int(d.manufacturing_country.nunique())}
aggregates={}
for col in ('category','manufacturer','battery_type','manufacturing_country','model_year'):
    g=d.groupby(col).agg(sales=('annual_sales_units','sum'),records=('record_key','size'),sales_records=('annual_sales_units','count'),rating=('customer_rating','mean'),rating_records=('customer_rating','count'),range_km=('range_km','mean'),capacity_kwh=('battery_capacity_kwh','mean')).reset_index()
    g['sales_share']=g.sales/metrics['total_sales']
    g.to_csv(out/'data'/f'summary_{col}.csv',index=False)
    aggregates[col]=g.sort_values('sales',ascending=False).to_dict('records')
metrics['aggregates']=aggregates
metrics['processing_seconds']=round(time.perf_counter()-start,3)
(base/'analysis.json').write_text(json.dumps(metrics,indent=2),encoding='utf8')
(out/'data'/'data_quality.json').write_text(json.dumps({k:v for k,v in metrics.items() if k!='aggregates'},indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in metrics.items() if k!='aggregates'},indent=2))
