import sys
from pathlib import Path
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base/'python_packages'))
from tableauhyperapi import HyperProcess,Telemetry,Connection,CreateMode,TableDefinition,TableName,SqlType,escape_string_literal
import xml.etree.ElementTree as E
out=base.parent/'outputs'/'EV Market Insights'/'data'
columns=E.parse(base/'seed.twb').getroot().findall('datasources/datasource/connection/relation/columns/column')
types={'string':SqlType.text,'integer':SqlType.big_int,'real':SqlType.double}
cols=[TableDefinition.Column(c.get('name'),types[c.get('datatype')]()) for c in columns]
cols.extend([TableDefinition.Column('source_split',SqlType.text()),TableDefinition.Column('record_key',SqlType.text())])
table=TableDefinition(TableName('Extract','Extract'),cols)
with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
    with Connection(hp.endpoint,str(out/'ev_market.hyper'),CreateMode.CREATE_AND_REPLACE) as cn:
        cn.catalog.create_schema('Extract');cn.catalog.create_table(table)
        n=cn.execute_command(f"COPY {table.table_name} FROM {escape_string_literal(str(out/'ev_market_clean.csv'))} WITH (format => 'csv', delimiter => ',', header => true)")
        print('Extract rows:',n)
