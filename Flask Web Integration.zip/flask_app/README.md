# Flask web integration

This app embeds the published Tableau dashboard and three-point scenario story. It serves a responsive page with navigation, a horizontally scrollable native Tableau view and a direct-link fallback. The fixed Tableau canvas retains its authored size.

## Run locally

Use Python 3.10 or later. In this directory:

```sh
python -m venv .venv
# Activate .venv for your shell, then:
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000/ for the dashboard or http://127.0.0.1:5000/story for the story. Internet access is required to load Tableau Public. The local Flask server binds to loopback with debug disabled. No credentials or private source files are used. No public hosting deployment is claimed.

## References

- https://help.tableau.com/current/pro/desktop/en-us/embed_code.htm
- https://help.tableau.com/current/pro/desktop/en-us/embed_list.htm
- https://flask.palletsprojects.com/en/stable/quickstart/
