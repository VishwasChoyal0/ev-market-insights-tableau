"""Serve the published EV dashboard and scenario story for local review."""
from flask import Flask, render_template, abort

app = Flask(__name__)
VIEWS = {
    "dashboard": ("Market dashboard", "EVMarketInsights"),
    "story": ("Scenario story", "ScenarioStory"),
}

@app.get("/")
@app.get("/<view>")
def index(view="dashboard"):
    if view not in VIEWS:
        abort(404)
    title, sheet = VIEWS[view]
    url = f"https://public.tableau.com/views/EVMarketInsights_17934697727980/{sheet}"
    return render_template("index.html", title=title, view=view, url=url)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
